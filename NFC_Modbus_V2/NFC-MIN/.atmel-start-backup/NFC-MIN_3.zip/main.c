#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		int a = 0;
		a = 10;
		//USART0.TXDATAL = 0x01;
		
	}
}
