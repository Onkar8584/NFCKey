
/**
 * \file
 *
 * \brief USART init driver.
 *
 (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms,you may use this software and
    any derivatives exclusively with Microchip products.It is your responsibility
    to comply with third party license terms applicable to your use of third party
    software (including open source software) that may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 */

/**
 * \defgroup doc_driver_usart_init USART Init
 * \ingroup doc_driver_usart
 *
 * \section doc_driver_usart_rev Revision History
 * - v0.0.0.1 Initial Commit
 *
 *@{
 */
#include <usart.h>
#include "clock_config.h"
#include "Build.h"
#include "string.h"
#include "assert.h"
#include "stdio.h"
/**
 * \brief Initialize usart interface
 *
 * \return Initialization status.
 */

uint8_t rxChars = 0;
uint8_t rxBuffer[50] = {0};
uint8_t txBuffer[50] = {0};
uint8_t rxIndex = 0;
uint8_t txIndex = 0;
uint8_t i = 0;

//temp data
uint8_t temp_buff[8] = {0x02,0x43,0x00,0x00,0x00,0x08,0xF0,0x45};
uint8_t temp_rxChars = 8;
int8_t USART_0_init()
{

	USART0.BAUD = (uint16_t)USART0_BAUD_RATE(19200); /* set baud rate register */

	USART0.CTRLA = 0 << USART_ABEIE_bp    /* Auto-baud Error Interrupt Enable: disabled */
	               | 0 << USART_DREIE_bp  /* Data Register Empty Interrupt Enable: disabled */
	               | 0 << USART_LBME_bp   /* Loop-back Mode Enable: disabled */
	               | USART_RS485_OFF_gc   /* RS485 Mode disabled */
	               | 1 << USART_RXCIE_bp  /* Receive Complete Interrupt Enable: enabled */
	               | 0 << USART_RXSIE_bp  /* Receiver Start Frame Interrupt Enable: disabled */
	               | 1 << USART_TXCIE_bp; /* Transmit Complete Interrupt Enable: enabled */

	USART0.CTRLB = 0 << USART_MPCM_bp       /* Multi-processor Communication Mode: disabled */
	               | 0 << USART_ODME_bp     /* Open Drain Mode Enable: disabled */
	               | 1 << USART_RXEN_bp     /* Reciever enable: enabled */
	               | USART_RXMODE_NORMAL_gc /* Normal mode */
	               | 0 << USART_SFDEN_bp    /* Start Frame Detection Enable: disabled */
	               | 1 << USART_TXEN_bp;    /* Transmitter Enable: enabled */

	// USART0.CTRLC = USART_CMODE_ASYNCHRONOUS_gc /* Asynchronous Mode */
	//		 | USART_CHSIZE_8BIT_gc /* Character size: 8 bit */
	//		 | USART_PMODE_DISABLED_gc /* No Parity */
	//		 | USART_SBMODE_1BIT_gc; /* 1 stop bit */

	// USART0.DBGCTRL = 0 << USART_DBGRUN_bp; /* Debug Run: disabled */

	// USART0.EVCTRL = 0 << USART_IREI_bp; /* IrDA Event Input Enable: disabled */

	// USART0.RXPLCTRL = 0x0 << USART_RXPL_gp; /* Receiver Pulse Lenght: 0x0 */

	// USART0.TXPLCTRL = 0x0 << USART_TXPL_gp; /* Transmit pulse length: 0x0 */

	return 0;
}

uint8_t USART_RxChar(byte *val)
{
	
	if(rxChars > 0)
	{
		//temp_rxChars -=1;
		//*val = temp_buff[i];
		rxChars -= 1;
		*val = rxBuffer[i];
		i++;
	}
	else
	{
		*val = 0;
		i = 0;
		rxIndex = 0;
		memset(rxBuffer, 0, 50);
		return 1;
	}
	
	return 0;
}

uint8_t USART_GetCharsInRxBuf(void)
{
	return rxChars;
	//return temp_rxChars;	
}

void USART_StoreData(void)
{
	if(USART0.STATUS & USART_RXCIF_bm)
	{
		byte data = USART0.RXDATAL;
		USART0.STATUS = USART_RXCIF_bm;
		rxBuffer[rxIndex++] = data;
		rxChars += 1;
		
		//USART0.TXDATAL = data;
		
	}
}

void USART_ClearRxBuffer(void)
{
	memset(rxBuffer, 0, 50);
	rxChars = 0;
	rxIndex = 0;
	i = 0;
	temp_rxChars = 8;
//	USART0.CTRLA |= (1 << USART_DREIE_bp);
}

void USART_SendChar(byte *str)
{
	//assert(*str);
	txBuffer[txIndex] = *str;
	while (!(USART0.STATUS & USART_DREIF_bm));
	USART0.TXDATAL = txBuffer[txIndex++];
	/*	while(*str)
	{
		x = *str;
		USART0.TXDATAL = *str;
		str++;
	}
	*/	
}

void check_crc()
{
	uint16_t temp;
	temp = ((uint16_t)rxBuffer[6]<<8) + ((uint16_t)rxBuffer[7]);
	printf("%d",temp);
}

void USART_ChangeBaudRate(uint8_t val)
{
	switch(val)
	{
		case BR_SELECT_19200:
			 USART0.BAUD = (uint16_t)USART0_BAUD_RATE(19200);
			 break;
		case BR_SELECT_38400:
			USART0.BAUD = (uint16_t)USART0_BAUD_RATE(38400);
			break;
		case BR_SELECT_57600:
			USART0.BAUD = (uint16_t)USART0_BAUD_RATE(57600);
			break;
		case BR_SELECT_115200:
			USART0.BAUD = (uint16_t)USART0_BAUD_RATE(115200);
			break;
		default:
			USART0.BAUD = (uint16_t)USART0_BAUD_RATE(19200);
			break;	
	}
}