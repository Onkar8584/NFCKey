#include <atmel_start.h>
#include "Class_level_Code/MinSlave.h"
MinSlave_STYP oMinSlave = MIN_DEFAULTS;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	MinSlave_init(&oMinSlave);
	/* Replace with your application code */
	while (1) {
	
	}
}
