/*
 * IoTranslate.h
 *
 * Created: 8/28/2019 2:28:34 PM
 *  Author: anvenkataraman
 */ 


#ifndef IOTRANSLATE_H_
#define IOTRANSLATE_H_
#include <driver_init.h>

#define HardwareUart_setBaudRate(x) USART0.BAUD = (uint16_t)USART0_BAUD_RATE(x);


#endif /* IOTRANSLATE_H_ */