/*
=======================================================================================
File name:    BlockStructures.h                  
                    
Originator:   Tom Van Sistine

Description:

    Defines the block structures and definitions for MIN Master of MIN interface.
 
Class Methods:
  None

Resources:

  Data storage for all registers and a block info table.

=======================================================================================
 History:	
*-------*-----------*---------------------------------------------------*--------------
1.00	07-10-2019	Initial Write										Tom Van Sistine

 --------------------------------------------------------------------------------------
*/
#ifndef BLOCKSTRUCTURE_H_
#define BLOCKSTRUCTURE_H_

#define MIN_RECEIVE_BLOCK_SIZE (uint16_t) 128U // 128 registers is maximum block size

// DEFINE BLOCK NUMBERS.
#define NUMBER_OF_BLOCKS 2

// enum of blocks supported
enum {
	BLOCK0 = 0,
	BLOCK1 = 1,

};

// DEFINE ALL THE BLOCK PARAMETERS HERE

enum {
	B0_CURRENT_FW_VERSION_REVISION = 0,
	B0_CURRENT_HW_VERSION_REVISION,

	B0_SIZE
};

enum {
	B1_UPPER_TEMP_RNUM = 0,
	B1_LOWER_TEMP_RNUM,
	B1_TANK_TEMP_RNUM,

	B1_SIZE
};


// NOTE: IF HIGHER BLOCK NUMBER ADDED HERE, ADD ALSO TO AllBlocks_STYP AND
//       BLOCK_INFORMATION_DEFAULTS BELOW


// Create a block information structure type that will be an array containing all the blocks
// blocks sizes and starting addresses of MIN register storage for each block as defined
// in BLOCK_INFORMATION_DEFAULTS below.

typedef struct BlockInformation_STYP{
	uint8_t blockSize;
	uint16_t * blockDataStart;
}BlockInformation_STYP;

typedef struct AllBlocks_STYP{											// ADD BLOCKS HERE....
	uint16_t block0_parameters[B0_SIZE];
	uint16_t block1_parameters[B1_SIZE];
}AllBlocks_STYP;
															// ...AND DEFAULTS HERE.
#define BLOCK_STRUCTURE_DEFAULTS {    					\
		{B0_SIZE, minRegisters.block0_parameters},   	\
		{B1_SIZE, minRegisters.block1_parameters},   	\
}


#endif /* BLOCKSTRUCTURE_H_ */
