/*
=======================================================================================
File name:    NFC.h                 
                    
Originator:   Anish Venkataraman

Description:

This module uses the I2cDrive driver module for communicating with the NFC chip.
This is a higher level module for the low level I2c driver.

Multi-Instance: No

Class Methods:
NFC_WriteByte(uint16_t address, unsigned char data)		//Called from Scheduler.c
NFC_ReadByte(uint16_t address);							//Called from Scheduler.c and MinSlave.c
NFC_CurrentRead();				
NFC_Write(NFC_STYP *nfc);								//Called from Scheduler.c
NFC_Read(NFC_STYP *nfc);								//Called from Scheduler.c
Peripheral Resources:
Assume as UART is available for 19,200 up to 115,200 baud

IoTranslate requirements:

Other requirements:



=======================================================================================
 History:	(Identify methods that changed)
*-------*-----------*---------------------------------------------------*--------------
1.00	11-04-2019	Initial Code									 Anish Venkataraman
1.01	11-21-2019	Modified class structure and added macros		 Anish Venkataraman
					Added status and error enums
1.02	06-15-2020	Modified class structure and added macros		 Anish Venkataraman
					to support BLK 226
 ---------------------------------------------------------------------------------------
*/


#ifndef NFC_H_
#define NFC_H_

#include "Build.h"
#include "BlockStructures.h"

//Macros
#define UNKNOWN_WATER_HEATER	0x0000	//config code for unkown water heater
#define BLOCK2_OFFSET			0x003C  //temp block 2 offset
#define BLOCK11_OFFSET			0x300	//temp block 11 offset
#define BLOCK226_OFFSET			0x500	//temp block 226 offset
#define BLOCK_NVM_OFFSET		0x700	//temp block NVM information offset
#define NFC_MAX_MEM				250	    //Max Memory
#define NFC_WRITE_TIME			5	    //5ms per write cycle
#define MSB_MASK 8
#define LSB_MASK 0xFF
#define NO_RETRIES				0
#define MAX_RETRIES				3
#define NFC_BLK11_INDEX			200
#define NFC_BLK2_INDEX			0
#define NFC_DEFAULTS			\
		{FALSE,					\
		FALSE,					\
		FALSE,					\
		FALSE,					\
		{0},					\
		{{0},{0},{0}},			\
		NFC_IDLE_STATE,			\
		UNKNOWN_WATER_HEATER,	\
		NO_RETRIES,				\
		0,						\
		0}			
		


//Class Structure
typedef struct{
	bool NFC_WriteFLG;
	bool NFC_WriteBLK11Flag;
	bool NFC_WriteBLK226Flag;
	bool NFC_WriteProduct_Info_FLG;
	uint8_t storeData[NFC_MAX_MEM];
	AllBlocks_STYP minReg;
	uint8_t status;
	uint16_t configuration;
	uint8_t retryCount;
	uint8_t blockInfo;
	uint8_t startAddr;
	uint8_t dataLength;
}NFC_STYP;

//Public Methods for Class
void NFC_WriteByte(uint16_t address, unsigned char data);
uint8_t NFC_SequentialWrite(NFC_STYP *nfc, uint16_t address, uint8_t block);
uint8_t NFC_InstantaneousWrite(NFC_STYP *nfc, uint16_t address, uint8_t block);
uint8_t NFC_ReadByte(uint16_t address);
uint8_t NFC_WriteDataPRIV(uint16_t value);
uint8_t NFC_CurrentRead(void);
byte NFC_Write(NFC_STYP *nfc);
byte NFC_Read(NFC_STYP *nfc);
void NFC_init(NFC_STYP *nfc);
void NFC_WriteSequentialData(NFC_STYP *nfc, uint16_t address, uint8_t block);

//Status
enum{
	NFC_IDLE_STATE = 0,
	NFC_ERROR_STATE,
	NFC_WRITE_WAIT_STATE,
	NFC_WRITE_CHECK_STATE,
	NFC_RETRY_STATE
	};

//Error Write
enum{
	NO_WRITE_ERR = 0,
	NFC_WRITE_ERR,
	};
	
//Error Read
enum{
	NO_READ_ERR = 0,
	NFC_READ_ERR
};

//Block Inf
enum{
	NFC_BLK_2 = 0,
	NFC_BLK_11,
	NFC_BLK_226
};


#endif /* NFC_H_ */