#include <atmel_start.h>
#include "MyMain.h"
#include "i2c_simple_master.h"
uint8_t d[] = {0x00,0x00,0xFD};
	uint8_t data[] = {0x00,0x00,0x21,2,3,5,4,7,8,9,1,1,3,4,5,6,7,8,9};
	uint8_t erro = 0xff;
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	//erro = I2C_0_writeNBytes(0xA6,d,3);
	MyMain_main();
	
	while (1) {
	printf("hi");
	erro = I2C_0_writeNBytes(0xA6,data,3);
	printf("hi");
	}
}
