/*
 * IoTranslate.h
 *
 * Created: 8/28/2019 2:28:34 PM
 *  Author: anvenkataraman
 */ 


#ifndef IOTRANSLATE_H_
#define IOTRANSLATE_H_
#include <driver_init.h>
#include "usart.h"
#include "atmel_start_pins.h"
#include "Build.h"

#define HardwareUart_setBaudRate(x) USART_ChangeBaudRate(x)
#define HardwareUart_Init() USART_0_initialization()
#define HardwareUart_RecvChar(x) USART_RxChar(&x)
#define HardwareUart_SendChar(x) USART_SendChar(&x)
#define HardwareUart_GetCharsInRxBuf() (uint8_t)USART_GetCharsInRxBuf()
#define HardwareUart_getError()	0
#define HardwareUart_clearRxBuf() USART_ClearRxBuffer()
#define minRxEnable()	Tx_Enable_set_level(FALSE);
#define minTxEnable()	Tx_Enable_set_level(TRUE);

#endif /* IOTRANSLATE_H_ */