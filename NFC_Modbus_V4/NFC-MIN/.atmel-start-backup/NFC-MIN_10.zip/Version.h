/*=====================================================================================
File name:    Version.h

Originator:   Anish Venkataraman

Description:  Software Project Revision History

Multi-Instance: N/A

Instance Methods: N/A

Peripheral Resources: N/A

IoTranslate requirements: N/A

Other requirements: N/A

=====================================================================================
 History:
-*-----*-----------*--------------------------------------------------*--------------
 1.00  12-02-2016  Commercial PAM (from original) with Flex slave     Tom Van Sistine
 	 	 	 	   addressing algorithm. AIN baud change to 38,400.
-------------------------------------------------------------------------------------
*/

#ifndef VERSION_H_
#define VERSION_H_

#define VERSION			0x01	// 1
#define REVISION		0x00	// 00
#define BUILDREVISION	0x01    // 01
#define FIRMWARE_VERSION_REVISION     ((VERSION << 8) + REVISION)  // i.e. 1.00.00


#endif /* VERSION_H_ */
