#include <atmel_start.h>
#include "Class_level_Code/MinSlave.h"
#include "NFC.h"
MinSlave_STYP oMinSlave = MIN_DEFAULTS;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	uint8_t dat = 0;
	MinSlave_init(&oMinSlave);
	//NFC_Write(0x0001,'A');
//	NFC_Write(0x000F,'X');
	//for(int i = 0;i < 10000;i++);
	//dat = NFC_Read(0x0001);
//	dat = NFC_CurrentRead();
	NFC_Write(0x000B,(unsigned char)dat);

	/* Replace with your application code */

	while (1) {
		/*LED_set_level(true);
		for(long int i = 0;i < 50000;i++);
		LED_set_level(false);
		for(long int i = 0;i < 50000;i++);
		*/
	}
}
