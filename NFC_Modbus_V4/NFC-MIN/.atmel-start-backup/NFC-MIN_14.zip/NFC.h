/*
 * NFC.h
 *
 * Created: 9/10/2019 12:46:50 PM
 *  Author: anvenkataraman
 */ 


#ifndef NFC_H_
#define NFC_H_
#include "stdint-gcc.h"

void NFC_Write(uint16_t address, unsigned char data);
uint8_t NFC_Read(uint16_t address);
uint8_t NFC_CurrentRead();

#endif /* NFC_H_ */