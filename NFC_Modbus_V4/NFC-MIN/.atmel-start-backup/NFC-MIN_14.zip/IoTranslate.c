/*
 * IoTranslate.c
 *
 * Created: 9/6/2019 2:08:13 PM
 *  Author: anvenkataraman
 */ 
#include "stdint.h"
#include "IoTranslate.h"
#include "atmel_start_pins.h"

void SDA_Write(unsigned char val)
{
	if(val)
	{
		SDA_set_level(TRUE);
	}
	else
	{
		SDA_set_level(FALSE);
	}
}

uint8_t SDA_Read(void)
{
	
	return SDA_get_level();
}

void Hardware_Delay()
{
	for(int i = 0; i < 5; i++);
	
}