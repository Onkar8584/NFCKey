/*
 * MinSlave.c
 *
 * Created: 8/28/2019 1:51:59 PM
 *  Author: anvenkataraman
 */ 

#include "MinSlave.h"
#include "IoTranslate.h"
#include <driver_init.h>

void MinSlave_manageMessages()
{
	unsigned char data = USART0_RXDATAL;
	USART0.STATUS = USART_RXCIF_bm;
	if (data == 'A')
	{
		HardwareUart_setBaudRate(115200);
		USART0.TXDATAL = data;
	}
	else if (data == 'B')
	{
		HardwareUart_setBaudRate(9600);
		USART0.TXDATAL = data;
	}
	else
	{
		
		HardwareUart_setBaudRate(19200);
		
		USART0.TXDATAL = data;
	}
	
}