#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		int a = 0;
		while(a != 10)
		{
			a++;
		}
		a = 0;
		
	}
}
