/*=====================================================================================
File name:    Version.h

Originator:   Anish Venkataraman

Description:  Software Project Revision History

Multi-Instance: N/A

Instance Methods: N/A

Peripheral Resources: N/A

IoTranslate requirements: N/A

Other requirements: N/A

=====================================================================================
 History:
-*-----*-----------*--------------------------------------------------*--------------
 1.00  9-10-2019  NFC-key with MIN protocol						   Anish Venkataraman
-------------------------------------------------------------------------------------
*/

#ifndef VERSION_H_
#define VERSION_H_

#define VERSION			0x01	// 1
#define REVISION		0x00	// 00
#define BUILDREVISION	0x07    // 07
#define FIRMWARE_VERSION_REVISION     ((VERSION << 8) + REVISION)  // i.e. 1.00.00



/*
Update firmware version information here (not above) Latest information first.

Date          FirmWare  File Changed      		File V/R  	Programmer        	Description
*---------------*-------*-----------------------*-----------*-------------------*---------------------------------------------------------------------------------------
06-16-2020		1.00.07	NFC.c								Anish Venkataraman
06-15-2020		1.00.06	MinSlave.c							Anish Venkataraman
						BlockStrucures.h
						Scheduler.c
						NFC.c
06-04-2020		1.00.05 MinSlave.c							Anish Venkataraman
						NFC.c					1.02
04-15-2020		1.00.04 MinSlave.c							Anish Venkataraman
						BlockStructures.h
11-21-2019		1.00.03 MyMain.c				1.03		Anish Venkataraman  Changed scheduling from 1m to 10min and added a check for every completion of NFC write.
						Scheduler.c				1.02						    Added a function Scheduler_checkNFCWrite	and modified Scheduler_serviceNFCWrite().
						LedCtrl.c				1.02						    Modified parameter type to uint16_t of LedCtrl_HeartBeatSetInterval method
						NFC.c					1.01						    Changed the name methods, modified NFC_Sequential_Write function and created additional 2 methods NFC_Write and NFC_Read
						NFC.h					1.01						    Modified class structure and added macros. Added status and error enums
						Scheduler.h				1.02							Added a new function Scheduler_checkNFCWrite & added a macro SCHEDULER_NFC_WAIT_TIME
						MyMain.h				1.03							Changed scheduling from 1m to 10min and	updated class structure.
11-5-2019		1.00.02 MyMain.c				1.02		Anish Venkataraman  Changed scheduling from 5msec to 1min

11-4-2019		1.00.01 MyMain.c				1.01		Anish Venkataraman  Adapted from CPAM code and modified as per the NFC project 
						Scheduler.c				1.01							Adapted from CPAM and added Scheduler_serviceNFCWrite() function.
						LedCtrl.c				1.01							Modified as per project specification
						MinSlave.c				1.04							Ported from CPAM code and Added code to read from NFC and append it to the 
																				MIN_SLAVE_MODEL_CONFIGURATION_CODE. Added code to store Block2 parameters
						MinUart.c				1.00							Ported from CPAM code
						
9-10-2019		1.00.00 Version.h				1.00		Anish Venkataraman  Initial file
						NFC.c					1.00							Created a higher level module for lower level I2c driver.
						I2cDrive.c				1.00							Ported from AOS library
						main.c					1.00							IDE generated file
						IoTranslate.c			1.00                            Created a file to map hardware related modules.                                                                                                         
*/	
#endif /* VERSION_H_ */



