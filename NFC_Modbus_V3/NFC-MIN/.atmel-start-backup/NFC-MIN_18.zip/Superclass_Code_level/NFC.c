/*
=======================================================================================
File name:    NFC.c                  
                    
Originator:   Anish Venkataraman



=======================================================================================
 History:	(Identify methods that changed)
*-------*-----------*---------------------------------------------------*--------------
1.0		9-10-2019	Initial Code									 Anish Venkataraman
1.01	11-21-2019	Modified name of methods and created two new	 Anish Venkataraman
					methods that act as helper to the methods. 
1.02	06-04-2020  Re-factored code, removed NFC_Write function,	 Anish Venkataraman
					created a new method for init and instantaneous
					write 
1.03	06-15-2020  Added support for writing BLK226				 Anish Venkataraman
					NFC_SequentilaWrite() 1.02	
1.04	06-16-2020  Added helper function for reducing code size	 Anish Venkataraman
					NFC_SequentilaWrite() 1.03	
					NFC_InstantaneousWrite() 1.01	
					NFC_WriteDataPRIV() 1.00		 
 ---------------------------------------------------------------------------------------
*/
#include "I2cDrive.h"
#include "MinSlave.h"
#include "stdint-gcc.h"
#include "NFC.h"
#include "ProductInfoNVM.h"
#include "i2c_simple_master.h"

extern MinSlave_STYP oMinSlave;
extern ProductInfoNvm_UTYP oProductInfo;
/*=======================================================================================
Method name:  NFC_WriteByte(uint16_t address, unsigned char data)

Originator:   Anish Venkataraman

Description:It takes a 16-bit address and a one byte of data. It performs a 
			random read access to the NFC chip. This process is done as follows
			1. Send I2C Start Signal
			2. Slave Select + R/W(set to 0) -> Device Address
			3. Send MSB-Byte address to be read followed by LSB-Byte address.
			4. Send data by calling I2cDrive_SendByte method(function).
			5.Send I2C Stop Signal


=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    9-10-2019   Original code                                   Anish Venkataraman
1.01	11-21-2019	Changed the name of the function from NFC_Write Anish Venkataraman
					to NFC_WriteByte
---------------------------------------------------------------------------------------*/
void NFC_WriteByte(uint16_t address, unsigned char data) {
	I2cDrive_Start();
	(void)I2cDrive_SendByte(NFC_ADDRESS_Write);
	(void)I2cDrive_SendByte(address >> MSB_MASK);
	(void)I2cDrive_SendByte(address & LSB_MASK);
	(void)I2cDrive_SendByte(data);
	I2cDrive_Stop();
}


/*=======================================================================================
Method name:  uint8_t NFC_SequentialWrite(NFC_STYP *nfc, uint16_t address)

Originator:   Anish Venkataraman

Description:It takes a 16-bit address and a pointer to the sequence of data. It performs a 
			sequential read access to the NFC chip. This process is done as follows
			1. Send I2C Start Signal
			2. Slave Select + R/W(set to 0) -> Device Address
			3. Send MSB-Byte address to be read followed by LSB-Byte address.
			4. Send data by calling I2cDrive_SendByte method(function).
			5. Wait for write to complete.(max of 5ms)
			6. Send data until everything is sent out
			7. Send I2C Stop Signal

Note: Max 256 characters can be written in one sequential write command
=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    10-9-2019   Original code                                   Anish Venkataraman
1.01    11-21-2019  Modified entire code                            Anish Venkataraman
1.02    06-15-2020  Added support for writing BLK226                Anish Venkataraman
1.03    06-16-2020  Added a helper function to reduce code size     Anish Venkataraman
---------------------------------------------------------------------------------------*/

uint8_t NFC_SequentialWrite(NFC_STYP *nfc, uint16_t address, uint8_t block) {
	uint8_t error;
	I2cDrive_Start();
	(void)I2cDrive_SendByte(NFC_ADDRESS_Write);
	(void)I2cDrive_SendByte(address >> MSB_MASK);
	(void)I2cDrive_SendByte(address & LSB_MASK);
	//Store Block 2 register data
	if(block == BLOCK2) {
		for(uint8_t i = nfc->startAddr; i < (nfc->dataLength/2); i++) {
			error = NFC_WriteDataPRIV(nfc->minReg.block2_parameters[i]);
			if(error == NFC_WRITE_ERR){
				return NFC_WRITE_ERR;
			}
		}
	}
	//Store Block 11 register data
	else if(block == BLOCK11) {
		for(uint8_t i = nfc->startAddr; i < (nfc->dataLength/2); i++) {
			error = NFC_WriteDataPRIV(nfc->minReg.block11_parameters[i]);
			if(error == NFC_WRITE_ERR){
				return NFC_WRITE_ERR;
			}
		}
	}
	//Store Block 226 register data
	else if(block == BLOCK226) {
		for(uint8_t i = nfc->startAddr; i < (nfc->dataLength/2); i++) {
			error = NFC_WriteDataPRIV(nfc->minReg.block226_parameters[i]);
			if(error == NFC_WRITE_ERR){
				return NFC_WRITE_ERR;
			}
		}
	}
	//Store Product Info register data
	else{
		for(uint8_t i = 0; i < MAX_SIZE_PRODUCT_INFO; i++) {
			error = I2cDrive_SendByte(oProductInfo.rxBuffer[i]);
			if(error == NFC_WRITE_ERR) {
				I2cDrive_Stop();
				return NFC_WRITE_ERR;
			}
		}
	}
	I2cDrive_Stop();
	return NO_WRITE_ERR;
}

/*=======================================================================================
Method name:uint8_t NFC_InstantaneousWrite(NFC_STYP *nfc, uint16_t address, uint8_t block)
Originator:   Anish Venkataraman

Description: This method writes a 2 bytes of data for block 2 and block 11 data. 


=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    06-04-2019   Original code                                   Anish Venkataraman
1.01    06-16-2020  Added a helper function to reduce code size      Anish Venkataraman
---------------------------------------------------------------------------------------*/

uint8_t NFC_InstantaneousWrite(NFC_STYP *nfc, uint16_t address, uint8_t block) {
	uint8_t error;
	I2cDrive_Start();
	(void)I2cDrive_SendByte(NFC_ADDRESS_Write);
	(void)I2cDrive_SendByte(address >> MSB_MASK);
	(void)I2cDrive_SendByte(address & LSB_MASK);
	//Store Block 2 register data
	if(block == BLOCK2) {
		error = NFC_WriteDataPRIV(nfc->minReg.block2_parameters[nfc->startAddr]);
		if(error == NFC_WRITE_ERR){
			return NFC_WRITE_ERR;
		}
		
	}
	//Store Block 11 register data
	else {
		error = NFC_WriteDataPRIV(nfc->minReg.block11_parameters[nfc->startAddr]);
		if(error == NFC_WRITE_ERR){
			return NFC_WRITE_ERR;
		}
	}
	I2cDrive_Stop();
	return NO_WRITE_ERR;
}
/*=======================================================================================
Method name:  NFC_ReadByte(uint16_t address)

Originator:   Anish Venkataraman

Description: It takes a 16-bit address and returns one byte of data. It performs a 
			random read access to the NFC chip. This process is done as follows
			1. Send I2C Start Signal
			2. Slave Select + R/W(set to 0) -> Device Address
			3. Send MSB-Byte address to be read followed by LSB-Byte address.
			4. Send another I2C Start Signal.
			5. Slave Select + R/W(set to 1) -> Device Address
			6. Read the SDA line to receive data
			7. Send I2C Stop Signal

=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    9-10-2019   Original code                                   Anish Venkataraman
---------------------------------------------------------------------------------------*/
uint8_t NFC_ReadByte(uint16_t address) {
	uint8_t data = 0;
	I2cDrive_Start();
	(void)I2cDrive_SendByte(NFC_ADDRESS_Write);
	(void)I2cDrive_SendByte(address >> MSB_MASK);
	(void)I2cDrive_SendByte(address & LSB_MASK);
	I2cDrive_Start();
	(void)I2cDrive_SendByte(NFC_ADDRESS_Read);
	data = I2cDrive_ReceiveByte();
	I2cDrive_NAckSend();
	I2cDrive_Stop();
	return data;
}

/*=======================================================================================
Method name:  NFC_CurrentRead()

Originator:   Anish Venkataraman

Description:The method returns a returns one byte of data. It performs a 
			current read access to the NFC chip. This process is done as follows
			1. Send I2C Start Signal
			2. Slave Select + R/W(set to 1) -> Device Address
			3. Read the SDA line to receive data
			4. Send I2C Stop Signal

Note: It has a internal counter that increments after each current read.
=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    9-10-2019   Original code                                   Anish Venkataraman
---------------------------------------------------------------------------------------*/

uint8_t NFC_CurrentRead(void)
{
	uint8_t data = 0;
	I2cDrive_Start();
	(void)I2cDrive_SendByte(NFC_ADDRESS_Read);
	data = I2cDrive_ReceiveByte();
	I2cDrive_Stop();
	return data;
}


/*=======================================================================================
Method name:  NFC_Read()

Originator:   Anish Venkataraman

Description:The method returns a returns status of random read operation. It reads all 
			data stored in BLOCK2 of NFC.


=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    11-21-2019   Original code                                   Anish Venkataraman
---------------------------------------------------------------------------------------*/

byte NFC_Read(NFC_STYP *nfc)
{
	uint8_t data = 0;
	uint8_t error;
	uint16_t addr = 0;
	
	for(uint8_t i = 0; i < (B2_SIZE*2); i++) {
		addr = BLOCK2_OFFSET + (uint16_t)i;
		data = NFC_ReadByte(addr);
		if((data == nfc->storeData[i]) && (nfc->status == NFC_WRITE_CHECK_STATE)) {
			error = NO_READ_ERR;
		}
		else {
			return NFC_READ_ERR;
		}
	}
	return error;
}

/*=======================================================================================
Method name:  NFC_init()

Originator:   Anish Venkataraman

Description: Initialization method for NFC. Reads the configuration code from NFC and
			 stores the value in the nfc object and Minslave object as well.	 


=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    11-21-2019   Original code                                   Anish Venkataraman
---------------------------------------------------------------------------------------*/

void NFC_init(NFC_STYP *nfc) {
	//nfc->configuration = NFC_ReadByte(0x0000) << 8;			//temp location for configuration
	//nfc->configuration |= NFC_ReadByte(0x0001);				//temp location for configuration
	oMinSlave.slaveRegisters[MIN_SLAVE_MODEL_CONFIGURATION_CODE] = nfc->configuration; //save configuration 
}

/*=======================================================================================
Method name:  NFC_WriteDataPRIV(uint16_t value)

Originator:   Anish Venkataraman

Description: This is a helper function to reduce code size It takes a 16-bit data
			 and breaks it into 2-bytes of data and sends it to NFC

=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    06-16-2020   Original code                                   Anish Venkataraman
---------------------------------------------------------------------------------------*/
uint8_t NFC_WriteDataPRIV(uint16_t value) {
	uint8_t data;
	uint8_t error = 0;
	data = value >> 8;
	error = I2cDrive_SendByte(data);
	if(error == NFC_WRITE_ERR){
		I2cDrive_Stop();
		return NFC_WRITE_ERR;
	}
	data = (uint8_t) value;
	error = I2cDrive_SendByte(data);
	if(error == NFC_WRITE_ERR) {
		I2cDrive_Stop();
		return NFC_WRITE_ERR;
	}
	return NO_WRITE_ERR;
}

static uint8_t txbuf[NFC_MAX_MEM];
uint8_t eror;
void NFC_WriteSequentialData(NFC_STYP *nfc, uint16_t address, uint8_t block) {
	uint8_t index = 0;
	uint8_t *dataPtr;
	uint8_t error;
	txbuf[0] = address >> 8;
	txbuf[1] = (uint8_t) address;
	dataPtr = &txbuf[2];
	if(block == BLOCK2) {
		for(uint8_t i = nfc->startAddr; i < (nfc->dataLength/2); i++) {
			*dataPtr++ = nfc->minReg.block2_parameters[i] >> 8;
			*dataPtr++ = (uint8_t) nfc->minReg.block2_parameters[i];
		}
	//	I2C_0_writeNBytes(0xA6,txbuf,nfc->dataLength+2);
	}
	else if (block == BLOCK11) {
		for(uint8_t i = nfc->startAddr; i < (nfc->dataLength/2); i++) {
			*dataPtr++ = nfc->minReg.block11_parameters[i] >> 8;
			*dataPtr++ = (uint8_t) nfc->minReg.block11_parameters[i];
		}
	}
	else if (block == BLOCK226) {
		for(uint8_t i = nfc->startAddr; i < (nfc->dataLength/2); i++) {
			*dataPtr++ = nfc->minReg.block226_parameters[i] >> 8;
			*dataPtr++ = (uint8_t) nfc->minReg.block226_parameters[i];
		}
	}
	else {
		
	}
	eror = I2C_0_writeNBytes(0xA6,txbuf,8);
	error = eror;
	//Hardware_SendBytes(0xD2,dataPtr,nfc->dataLength+2);
}