/*=====================================================================================
File name:    Scheduler.c                  
                    
Originator:   Tom Van Sistine

  
=======================================================================================
 History:	
*-------*-----------*---------------------------------------------------*--------------
1.00	01-13-2017	New File											Tom Van Sistine
1.01	11-04-2019	Adapted from CPAM and added 					 Anish Venkataraman
					Scheduler_serviceNFCWrite() function.
1.02	11-21-2019	Added a function Scheduler_checkNFCWrite		 Anish Venkataraman
					and modified Scheduler_serviceNFCWrite().
1.03	06-15-2020	Removed function Scheduler_checkNFCWrite		 Anish Venkataraman
					and modified Scheduler_serviceNFCWrite().
---------------------------------------------------------------------------------------
*/
//Includes
#include "NFC.h"
#include "Scheduler.h"
#include "MinSlave.h"
#include "LedCtrl.h"

extern MinSlave_STYP oMinSlave;
extern LedCtrl_STYP oLed;
extern NFC_STYP oNFC;

/*
=======================================================================================
Method name:  Schedule_manageTasks()
					
Originator:   Sun Ran

Description:  Called from main() every 1 mSec. 
			  Calls tasks at:
			   - LEDs
			   - Scheduler_minTimeoutCheck
			   - Scheduler_serviceNFCWrite
			    
	
Resources:	  

=======================================================================================
History:
*-----*-------------*---------------------------------------------------*--------------
1.00	06-30-2015	Original Code										Sun Ran
1.01	01-18-2017	Adapted from PAM with headers and comments added.   Tom Van Sistine
1.02	12-13-2017	Changed call to flash red LED to use prioritized 	Tom Van Sistine
                    Look Up Table to flash fewer times for common
                    problems.
1.03	08-02-2019  Added call to Scheduler_minTimeoutCheck()			Tom Van Sistine
---------------------------------------------------------------------------------------
*/
void Scheduler_manageTasks(void)
{
	uint8_t flashCode = 0;
	LedCtrl_ledsManager(&oLed,flashCode);
	Scheduler_minTimeoutCheck();
	
} 
/*
 ========================================================================================
 Method name:  Scheduler_serviceNFCWrite()

 Originator:   Anish Venkataraman

 Description:
 	 	 This routine is called every minute  and checks if there flag for  block is set or 
		 not. If it is set, it writes the data starting at an offset. Once all data is
		 written the flag is cleared.

 Resources:

 ========================================================================================
 History:
 *-------*-----------*---------------------------------------------------*---------------
 1.00    11-04-2019  Original code                                     Anish Venkataraman
 1.01	 11-21-2019  Modified the code to check for errors			   Anish Venkataraman
 1.02	 06-15-2020  Modified the code to support writing of		   Anish Venkataraman
					 block 11			  
 ----------------------------------------------------------------------------------------
*/

void Scheduler_serviceNFCWrite(void) {
	static uint8_t secondCounter = 1;
	 if (secondCounter == 2 ) {
		 if(oNFC.NFC_WriteFLG == TRUE && oNFC.status == NFC_IDLE_STATE) {
			(void)NFC_SequentialWrite(&oNFC,BLOCK2_OFFSET,BLOCK2);
			oNFC.NFC_WriteFLG = FALSE;
		 }
	 }
	 else if (secondCounter == 3) {
		 if(oNFC.NFC_WriteBLK11Flag == TRUE && oNFC.status == NFC_IDLE_STATE) {
			(void)NFC_SequentialWrite(&oNFC,BLOCK11_OFFSET,BLOCK11);
			oNFC.NFC_WriteBLK11Flag = FALSE;
		 }
		secondCounter = 1;
	 }
	 secondCounter++;
}


/*
 ========================================================================================
 Method name:  Scheduler_minTimeoutCheck()

 Originator:   Tom Van Sistine

 Description:
 	 	 If MIN timeout timer not zero, decrement.  If then 0 call reset uart to discover
 	 	 baud rate and reset.

 Resources:

 ========================================================================================
 History:
 *-------*-----------*---------------------------------------------------*---------------
 1.00    08-02-2019  Original code                                       Tom Van Sistine

 ----------------------------------------------------------------------------------------
 */

void Scheduler_minTimeoutCheck(void)
{
	
	if(oMinSlave.communicationTimeoutCNTR)
	{
		oMinSlave.communicationTimeoutCNTR--;
		if(oMinSlave.communicationTimeoutCNTR == 0) {
			oMinSlave.uart.baudSelect = BR_SELECT_115200;  // Set back to Discovery baud
			MinSlave_init(&oMinSlave);
			
		}
	}
}