/*
 * IoTranslate.h
 *
 * Created: 8/28/2019 2:28:34 PM
 *  Author: anvenkataraman
 */ 


#ifndef IOTRANSLATE_H_
#define IOTRANSLATE_H_
#include <driver_init.h>
#include "usart.h"
#include "atmel_start_pins.h"
#include "Build.h"

//MIN
#define HardwareUart_setBaudRate(x) USART_ChangeBaudRate(x)
#define HardwareUart_Init() USART_0_initialization()
#define HardwareUart_RecvChar(x) USART_RxChar(&x)
#define HardwareUart_SendChar(x) USART_SendChar(&x)
#define HardwareUart_GetCharsInRxBuf() (uint8_t)USART_GetCharsInRxBuf()
#define HardwareUart_getError()	0
#define HardwareUart_clearRxBuf() USART_ClearRxBuffer()
#define minRxEnable()	Tx_Enable_set_level(FALSE);
#define minTxEnable()	Tx_Enable_set_level(TRUE);



//I2C
void SDA_Write(unsigned char val);
uint8_t SDA_Read(void);
void Hardware_Delay(void);

#define I2C_SDA_OUTPUT() SDA_set_dir(PORT_DIR_OUT);//Set SDA as output
#define I2C_SCL_OUTPUT() //Set the SCL as output
#define I2C_SCL_SetVal() SCL_set_level(TRUE)//Set SCL to high
#define I2C_SDA_SetVal() SDA_set_level(TRUE)//Set SDA line to high
#define I2c_Delay()		Hardware_Delay()//I2c Delay
#define I2C_SDA_ClrVal() SDA_set_level(FALSE)//Set SDA line to low
#define I2C_SCL_ClrVal() SCL_set_level(FALSE)//Set SCL line to low
#define I2C_SDA_GetVal() SDA_Read()//Get value from SDA line
#define I2C_SDA_INPUT() SDA_set_dir(PORT_DIR_IN);//Set SDA as input to read
#define I2C_SDA_PutVal(x) SDA_Write(x)//Send data

#endif /* IOTRANSLATE_H_ */