/*
 * NFC.c
 *
 * Created: 9/10/2019 12:39:39 PM
 *  Author: anvenkataraman
 */ 
#include "I2cDrive.h"
#include "IoTranslate.h"
#include "atmel_start_pins.h"
#include "stdint-gcc.h"

#define LSB_MASK 0xFF
/*=======================================================================================
Method name:  NFC_Write(uint16_t address, unsigned char data)

Originator:   Anish Venkataraman

Description:It takes a 16-bit address and a one byte of data. It performs a 
			random read access to the NFC chip. This process is done as follows
			1. Send I2C Start Signal
			2. Slave Select + R/W(set to 0) -> Device Address
			3. Send MSB-Byte address to be read followed by LSB-Byte address.
			4. Send data by calling I2cDrive_SendByte method(function).
			5.Send I2C Stop Signal


=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    9-10-2019   Original code                                   Anish Venkataraman
---------------------------------------------------------------------------------------*/
void NFC_Write(uint16_t address, unsigned char data)
{
	I2cDrive_Start();
	I2cDrive_SendByte(NFC_ADDRESS_Write);
	I2cDrive_SendByte(address >> 8);
	I2cDrive_SendByte(address & LSB_MASK);
	I2cDrive_SendByte(data);
	I2cDrive_Stop();I2cDrive_Stop();
}


/*=======================================================================================
Method name:  NFC_Read(uint16_t address)

Originator:   Anish Venkataraman

Description: It takes a 16-bit address and returns one byte of data. It performs a 
			random read access to the NFC chip. This process is done as follows
			1. Send I2C Start Signal
			2. Slave Select + R/W(set to 0) -> Device Address
			3. Send MSB-Byte address to be read followed by LSB-Byte address.
			4. Send another I2C Start Signal.
			5. Slave Select + R/W(set to 1) -> Device Address
			6. Read the SDA line to receive data
			7. Send I2C Stop Signal


=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    9-10-2019   Original code                                   Anish Venkataraman
---------------------------------------------------------------------------------------*/
uint8_t NFC_Read(uint16_t address)
{
	uint8_t data = 0;
	I2cDrive_Start();
	I2cDrive_SendByte(NFC_ADDRESS_Write);
	I2cDrive_SendByte(address >> 8);
	I2cDrive_SendByte(address & LSB_MASK);
	I2cDrive_Start();
	I2cDrive_SendByte(NFC_ADDRESS_Read);
	data = I2cDrive_ReceiveByte();
	I2cDrive_Stop();
	return data;
}

/*=======================================================================================
Method name:  NFC_CurrentRead()

Originator:   Anish Venkataraman

Description:The method returns a returns one byte of data. It performs a 
			current read access to the NFC chip. This process is done as follows
			1. Send I2C Start Signal
			2. Slave Select + R/W(set to 1) -> Device Address
			3. Read the SDA line to receive data
			4. Send I2C Stop Signal


=======================================================================================
History:
*-------*-----------*---------------------------------------------------*--------------
1.00    9-10-2019   Original code                                   Anish Venkataraman
---------------------------------------------------------------------------------------*/

uint8_t NFC_CurrentRead()
{
	uint8_t data = 0;
	I2cDrive_Start();
	I2cDrive_SendByte(NFC_ADDRESS_Read);
	data = I2cDrive_ReceiveByte();
	I2cDrive_Stop();
	return data;
}