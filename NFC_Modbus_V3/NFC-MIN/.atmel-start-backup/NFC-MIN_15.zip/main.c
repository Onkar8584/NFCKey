#include <atmel_start.h>
#include "Class_level_Code/MinSlave.h"
#include "NFC.h"
MinSlave_STYP oMinSlave = MIN_DEFAULTS;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	uint8_t dat = 0;
	uint8_t t = 0;
	MinSlave_init(&oMinSlave);
	NFC_Write(0x0000,'b');
	NFC_Write(0x0005,'2');
	//NFC_Write(0x000A,'e');
	/* Replace with your application code */

	while (1) {


	}
}
