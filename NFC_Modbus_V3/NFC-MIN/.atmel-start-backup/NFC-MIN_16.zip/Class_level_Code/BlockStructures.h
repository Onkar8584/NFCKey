/*
=======================================================================================
File name:    BlockStructures.h                  
                    
Originator:   Tom Van Sistine

Description:

    Defines the block structures and definitions for MIN Master of MIN interface.
 
Class Methods:
  None

Resources:

  Data storage for all registers and a block info table.

=======================================================================================
 History:	
*-------*-----------*---------------------------------------------------*--------------
1.00	07-10-2019	Initial Write										Tom Van Sistine
1.01	11-04-2019	Modified Block2 and Block 0 enum				 Anish Venkataraman
1.02	04-15-2020	Added auto test complete and Block 11 enum		 Anish Venkataraman
1.03	06-15-2020	Modified enums to support BLK11,BLK226			 Anish Venkataraman
 --------------------------------------------------------------------------------------
*/
#ifndef BLOCKSTRUCTURE_H_
#define BLOCKSTRUCTURE_H_

#define MIN_RECEIVE_BLOCK_SIZE (uint16_t) 128U // 128 registers is maximum block size

// DEFINE BLOCK NUMBERS.
#define NUMBER_OF_BLOCKS 254

// enum of blocks supported
enum {
	BLOCK0 = 0,
	BLOCK1 = 1,
	BLOCK2 = 2,
	BLOCK11 = 11,
	BLOCK226 = 226,
};

// DEFINE ALL THE BLOCK PARAMETERS HERE

enum {
	B0_CURRENT_FW_VERSION_REVISION = 0,
	B0_CURRENT_HW_VERSION_REVISION,
	B0_MAX_BAUDRATE_SUPPORTED,
	B0_EEPROM_INIT_VALUE,
	B0_ORIGINAL_FW_VERSION_REVISION,
	B0_ORIGINAL_HW_VERSION_REVISION,
	B0_CURRENT_FIRMWARE_BUILD,
	B0_MODEL_CONFIGURATION_CODE,
	B0_BRAND,
	B0_GALLONS,
	B0_RESERVED_1,
	B0_RESERVED_2,
	B0_RESERVED_3,
	B0_RESERVED_4,
	B0_RESERVED_5,
	B0_RESERVED_6,
	B0_MODEL_NUMBER_0,
	B0_MODEL_NUMBER_1,
	B0_MODEL_NUMBER_2,
	B0_MODEL_NUMBER_3,
	B0_MODEL_NUMBER_4,
	B0_MODEL_NUMBER_5,
	B0_MODEL_NUMBER_6,
	B0_MODEL_NUMBER_7,
	B0_MODEL_NUMBER_8,
	B0_MODEL_NUMBER_9,
	B0_MODEL_NUMBER_10,
	B0_MODEL_NUMBER_11,
	B0_MODEL_NUMBER_12,
	B0_MODEL_NUMBER_13,
	B0_MODEL_NUMBER_14,
	B0_SERIAL_NUMBER_0,
	B0_SERIAL_NUMBER_1,
	B0_SERIAL_NUMBER_2,
	B0_SERIAL_NUMBER_3,
	B0_SERIAL_NUMBER_4,
	B0_SERIAL_NUMBER_5,
	B0_SERIAL_NUMBER_6,
	B0_SERIAL_NUMBER_7,
	B0_SERIAL_NUMBER_8,
	B0_SERIAL_NUMBER_9,
	B0_SERIAL_NUMBER_10,
	B0_SERIAL_NUMBER_11,
	B0_SERIAL_NUMBER_12,
	B0_SERIAL_NUMBER_13,
	B0_SERIAL_NUMBER_14,
	
	B0_SIZE
};

enum {
	B1_UPPER_TEMP_RNUM = 0,
	B1_LOWER_TEMP_RNUM,
	B1_TANK_TEMP_RNUM,

	B1_SIZE
};


//Block 2
enum {

	B2_SIZE = 85,
	B11_SIZE = 25,
	B226_SIZE = 20,
};


// NOTE: IF HIGHER BLOCK NUMBER ADDED HERE, ADD ALSO TO AllBlocks_STYP AND
//       BLOCK_INFORMATION_DEFAULTS BELOW


// Create a block information structure type that will be an array containing all the blocks
// blocks sizes and starting addresses of MIN register storage for each block as defined
// in BLOCK_INFORMATION_DEFAULTS below.

typedef struct BlockInformation_STYP{
	uint8_t blockSize;
	uint16_t * blockDataStart;
}BlockInformation_STYP;

typedef struct AllBlocks_STYP{											// ADD BLOCKS HERE....
	uint16_t block0_parameters[B0_SIZE];
	uint16_t block2_parameters[B2_SIZE];
	uint16_t block11_parameters[B11_SIZE];
	uint16_t block226_parameters[B226_SIZE];
}AllBlocks_STYP;
															// ...AND DEFAULTS HERE.
#define BLOCK_STRUCTURE_DEFAULTS {    					\
		{B0_SIZE, minRegisters.block0_parameters},   	\
		{B2_SIZE, minRegisters.block2_parameters},		\
		{B11_SIZE, minRegisters.block11_parameters},	\
		{B226_SIZE, minRegisters.block226_parameters}, 	\
}




#endif /* BLOCKSTRUCTURE_H_ */
