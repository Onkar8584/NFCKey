/*
=======================================================================================
File name:    MyMain.c                  
                    
Originator:   Tom Van Sistine



=======================================================================================
 History:	(Identify methods that changed)
*-------*-----------*---------------------------------------------------*--------------
1.00	01-13-2017	Initial code.										Tom Van Sistine
1.01	11-04-2019	Adapted from CPAM code							 Anish Venkataraman
1.02	11-05-2019	Changed scheduling from 5msec to 1min			 Anish Venkataraman
 ---------------------------------------------------------------------------------------
*/

//Includes
#include "MinSlave.h"
#include "MyMain.h"
#include "Scheduler.h"
//#include "IoTranslate.h"
#include "LedCtrl.h"
//#include "Build.h"
#include "NFC.h"
#include "ProductInfoNVM.h"
//------------------ Instantiate all class objects here --------------------------------
MinSlave_STYP oMinSlave = MIN_DEFAULTS;
LedCtrl_STYP oLed;
NFC_STYP oNFC = NFC_DEFAULTS;
//ProductInfoNvm_STYP oProductInfo;
ProductInfoNvm_UTYP oProductInfo; 
// Instantiate itself.
MyMain_STYP mainObject;

/*
=======================================================================================
Method name:  MyMain_systemInit()
					
Originator:   Sun Ran

Description: 
	Initialize all objects.
	
Resources:

=======================================================================================
History:
*-----*-------------*---------------------------------------------------*--------------
1.00	06-30-2015	Original Code										Sun Ran
1.01	11-04-2019	Modified for NFC									Anish Venkataraman

---------------------------------------------------------------------------------------
*/

void MyMain_systemInit(void)
{
	LedCtrl_init(&oLed);
	MinSlave_init(&oMinSlave);
	NFC_init(&oNFC);
}
/*
=======================================================================================
Method name:  MyMain_main()
					
Originator:   Tom Van Sistine

Description: 
	Main loop code called from the function main() but does not return.
	Rather it does a normal main() function without the auto-generated code nor have the
	Processor Expert (PE) comments.
	
	MyMain() looks therefore like a standard Main.c file and is more portable show we
	go away from a PE project.
	
	It monitors the 1 msec timer flag set in driver_isr.c and calls Scheduler_run().  
	
Resources:

=======================================================================================
History:
*-----*-------------*---------------------------------------------------*--------------
1.00	01-13-2017	Original code based on main() from PAM by Sun Ran.  Tom Van Sistine
1.01    11-04-2019	Added a 5ms check flag to service NFC write		 Anish Venkataraman
					operation
1.02	11-05-2019	Changed scheduling from 5msec to 1min			 Anish Venkataraman
1.03	11-21-2019	Changed scheduling from 1m to 10min and			 Anish Venkataraman
					added a check for every completion of NFC write.
---------------------------------------------------------------------------------------
*/
void MyMain_main(void)
{
	//Initialize Objects
	MyMain_systemInit();
	
	while(1)
	{
		//1ms interrupt check
		if(mainObject.realTimeInterruptFlag == TRUE)			// Set every 1 msec in driver_isr.c
		{
			mainObject.realTimeInterruptFlag = FALSE;
			Scheduler_manageTasks();
			
		}
		//10min interrupt check
		if(mainObject.schedulerNFCRunFlag == TRUE)				// Set every 10min in driver_isr.c
		{
			//Writes to NFC's memory if the there is any data to be written
			Scheduler_serviceNFCWrite();
			mainObject.schedulerNFCRunFlag = FALSE;
		}
	/*
		if(mainObject.schedulerNFCWriteCheck == TRUE)			// Set after every write to NFC
		{	//Checks if data written is right or not
			Scheduler_checkNFCWrite();
			mainObject.schedulerNFCWriteCheck = FALSE;
		}
		*/
	}
}