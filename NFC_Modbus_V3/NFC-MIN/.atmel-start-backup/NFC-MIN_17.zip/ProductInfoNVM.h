#ifndef PRODUCTINFONVM_H_
#define PRODUCTINFONVM_H_

typedef struct{
  uint32_t softwareVer;	
  uint32_t hardwareVer;
} SwHwVersion_STYP;

typedef struct{
	uint16_t initialized;	// If new is 0xFFFF meaning not initialized.
	// After initialization this set to 0x5A5A.
	SwHwVersion_STYP currentProductInfo;         // Current versions (OTA or field changed) MR
	SwHwVersion_STYP originalProductInfo;        // As shipped to verify field changes. MR
	char serialNumber[20];                       // MR
	char modelNumber[20];                        // MR
	uint16_t configurationCode;                  // MR
	uint16_t ProductInfoCRC;                     // calculated when data changes.
} ProductInfoNvm_STYP;


typedef union{
	ProductInfoNvm_STYP info;
	uint8_t rxBuffer[sizeof(ProductInfoNvm_STYP)];
}ProductInfoNvm_UTYP;


#define MAX_SIZE_PRODUCT_INFO sizeof(ProductInfoNvm_STYP)

#endif /* PRODUCTINFONVM_H_ */